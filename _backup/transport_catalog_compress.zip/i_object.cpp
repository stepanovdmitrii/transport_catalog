#include "i_object.h"

Svg::IObject::~IObject()
{
}
