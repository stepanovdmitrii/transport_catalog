#include "comp_context.h"

Catalog::ComputationContext::ComputationContext(double height, double padding, double x_step, double y_step, std::vector<double>&& ordered_lon, std::vector<double>&& ordered_lat):
	_height(height), _padding(padding), _x_step(x_step), _y_step(y_step), _ordered_lon(std::move(ordered_lon)), _ordered_lat(std::move(ordered_lat))
{
}

Svg::Point Catalog::ComputationContext::GetProjection(const Models::Position& position) const
{
	Svg::Point p;
	auto lon_ub = std::upper_bound(_ordered_lon.begin(), _ordered_lon.end(), position.lon);
	auto lon_it = std::prev(lon_ub);
	size_t idx = std::distance(_ordered_lon.begin(), lon_it);
	p.x = idx * _x_step + _padding;
	auto lat_ub = std::upper_bound(_ordered_lat.begin(), _ordered_lat.end(), position.lat);
	auto lat_it = std::prev(lat_ub);
	idx = std::distance(_ordered_lat.begin(), lat_it);
	p.y = _height - _padding - idx * _y_step;
	return std::move(p);
}
