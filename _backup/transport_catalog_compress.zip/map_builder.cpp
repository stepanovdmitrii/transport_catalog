#include "map_builder.h"

void Catalog::MapBuilder::Setup(const Models::MapBuilderParameters& params)
{
	_parameters = params;
}

std::unique_ptr<Svg::Document> Catalog::MapBuilder::DrawSvg(const Catalog::BusShedule& bus_schedule) const
{
	std::unique_ptr<Svg::Document> doc = std::make_unique<Svg::Document>();
	std::unique_ptr<Catalog::ComputationContext> context = GetContext(bus_schedule);
	for (const auto& l : _parameters.layers) {
		if (l == "bus_lines") {
			DrawBusLines(bus_schedule, *doc, *context);
		}
		else if (l == "bus_labels") {
			DrawBusLabels(bus_schedule, *doc, *context);
		}
		else if (l == "stop_points") {
			DrawStops(bus_schedule, *doc, *context);
		}
		else if (l == "stop_labels") {
			DrawStopLabels(bus_schedule, *doc, *context);
		}
	}
	return std::move(doc);
}

std::unique_ptr<Catalog::ComputationContext> Catalog::MapBuilder::GetContext(const Catalog::BusShedule& bus_schedule) const
{
	std::vector<Models::Stop> ordered_lon_all;
	std::vector<Models::Stop> ordered_lat_all;

	for (const auto& s : bus_schedule.GetStops()) {
		ordered_lon_all.push_back(s.second);
		ordered_lat_all.push_back(s.second);
	}
	std::sort(ordered_lon_all.begin(), ordered_lon_all.end(), [](const Models::Stop& lhs, const Models::Stop& rhs) {return lhs.position.lon < rhs.position.lon; });
	std::sort(ordered_lat_all.begin(), ordered_lat_all.end(), [](const Models::Stop& lhs, const Models::Stop& rhs) {return lhs.position.lat < rhs.position.lat; });

	std::vector<Models::Stop> ordered_lon = RemoveNeighbors(bus_schedule, ordered_lon_all);
	std::vector<Models::Stop> ordered_lat = RemoveNeighbors(bus_schedule, ordered_lat_all);

	double lon_step = 0.0;
	if (ordered_lon.size() > 1) {
		lon_step = (_parameters.width - 2 * _parameters.padding) / (ordered_lon.size() - 1);
	}
	double lat_step = 0.0;
	if (ordered_lat.size() > 1) {
		lat_step = (_parameters.height - 2 * _parameters.padding) / (ordered_lat.size() - 1);
	}

	std::vector<double> ordered_lon_values;
	std::vector<double> ordered_lat_values;

	for (const auto& p : ordered_lon) {
		ordered_lon_values.push_back(p.position.lon);
	}

	for (const auto& p : ordered_lat) {
		ordered_lat_values.push_back(p.position.lat);
	}

	return std::make_unique<Catalog::ComputationContext>(_parameters.height, _parameters.padding, lon_step, lat_step, std::move(ordered_lon_values), std::move(ordered_lat_values));
}

void Catalog::MapBuilder::DrawBusLines(const Catalog::BusShedule& bus_schedule, Svg::Document& document, const Catalog::ComputationContext& context) const
{
	size_t bus_index = 0;
	for (const auto& pair : bus_schedule.GetBuses()) {
		Svg::Color stroke = _parameters.color_palette[bus_index % _parameters.color_palette.size()];
		Svg::Polyline line;
		line.SetStrokeColor(stroke)
			.SetStrokeWidth(_parameters.line_width)
			.SetStrokeLineCap("round")
			.SetStrokeLineJoin("round");
		for (const std::string& stop : pair.second.stops) {
			auto position = bus_schedule.GetStopPosition(stop);
			line.AddPoint(context.GetProjection(position));
		}
		document.Add(std::move(line));
		++bus_index;
	}
}

void Catalog::MapBuilder::DrawStops(const Catalog::BusShedule& bus_schedule, Svg::Document& document, const Catalog::ComputationContext& context) const
{
	for (const auto& s : bus_schedule.GetStops()) {
		Svg::Circle c;
		c.SetCenter(context.GetProjection(s.second.position))
			.SetRadius(_parameters.stop_radius)
			.SetFillColor("white");
		document.Add(std::move(c));
	}
}

void Catalog::MapBuilder::DrawStopLabels(const Catalog::BusShedule& bus_schedule, Svg::Document& document, const Catalog::ComputationContext& context) const
{
	for (const auto& s : bus_schedule.GetStops()) {
		Svg::Text label;
		Svg::Text underlayer;
		label.SetPoint(context.GetProjection(s.second.position))
			.SetOffset(_parameters.stop_label_offset)
			.SetFontSize(_parameters.stop_label_font_size)
			.SetFontFamily("Verdana")
			.SetData(s.first)
			.SetFillColor("black");
		underlayer.SetPoint(context.GetProjection(s.second.position))
			.SetOffset(_parameters.stop_label_offset)
			.SetFontSize(_parameters.stop_label_font_size)
			.SetFontFamily("Verdana")
			.SetData(s.first)
			.SetFillColor(_parameters.underlayer_color)
			.SetStrokeColor(_parameters.underlayer_color)
			.SetStrokeWidth(_parameters.underlayer_width)
			.SetStrokeLineCap("round")
			.SetStrokeLineJoin("round");
		document.Add(std::move(underlayer));
		document.Add(std::move(label));
	}
}

void Catalog::MapBuilder::DrawBusLabels(const Catalog::BusShedule& bus_schedule, Svg::Document& document, const Catalog::ComputationContext& context) const
{
	size_t bus_index = 0;
	for (const auto& p : bus_schedule.GetBuses()) {
		Svg::Color color = _parameters.color_palette[bus_index % _parameters.color_palette.size()];
		if (p.second.is_roundtrip) {
			const std::string& stop_name = p.second.stops[0];
			DrawBusLabel(document, context.GetProjection(bus_schedule.GetStopPosition(stop_name)), color, p.first);
		}
		else {
			const std::string& start_stop_name = p.second.stops[0];
			const std::string& finish_stop_name = p.second.stops[(p.second.stops.size() - 1) / 2];
			DrawBusLabel(document, context.GetProjection(bus_schedule.GetStopPosition(start_stop_name)), color, p.first);
			if (start_stop_name != finish_stop_name) {
				DrawBusLabel(document, context.GetProjection(bus_schedule.GetStopPosition(finish_stop_name)), color, p.first);
			}
			else {
				std::cerr << "same" << std::endl;
			}
		}
		bus_index++;
	}
}

void Catalog::MapBuilder::DrawBusLabel(Svg::Document& document, Svg::Point position, const Svg::Color& color, const std::string& name) const
{
	Svg::Text underlayer;
	underlayer
		.SetPoint(position)
		.SetOffset(_parameters.bus_label_offset)
		.SetFontSize(_parameters.bus_label_font_size)
		.SetFontFamily("Verdana")
		.SetFontWeight("bold")
		.SetData(name)
		.SetFillColor(_parameters.underlayer_color)
		.SetStrokeColor(_parameters.underlayer_color)
		.SetStrokeWidth(_parameters.underlayer_width)
		.SetStrokeLineCap("round")
		.SetStrokeLineJoin("round");
	Svg::Text label;
	label
		.SetPoint(position)
		.SetOffset(_parameters.bus_label_offset)
		.SetFontSize(_parameters.bus_label_font_size)
		.SetFontFamily("Verdana")
		.SetFontWeight("bold")
		.SetData(name)
		.SetFillColor(color);
	document.Add(underlayer);
	document.Add(label);
}

bool Catalog::MapBuilder::AreNeighborsOnSameRoute(const Catalog::BusShedule& bus_schedule, const Models::Stop& first, const Models::Stop& second) const
{
	std::set<std::string> common_busses;

	for (const auto& from_first : first.buses) {
		for (const auto& from_secod : second.buses) {
			if (from_first == from_secod) {
				common_busses.insert(from_first);
			}
		}
	}
	if (common_busses.size() == 0) {
		return false;
	}

	std::string prev;
	for (const std::string& bus : common_busses) {
		auto bus_stops = bus_schedule.FindBusStops(bus);
		if (false == bus_stops.has_value()) {
			continue;
		}
		prev = "";
		for (const auto& s : bus_stops.value()) {
			if ((s == first.name ) && (prev == second.name)) {
				return true;
			}
			if ((s == second.name) && (prev == first.name)) {
				return true;
			}
			prev = s;
		}
	}
	return false;
}

std::vector<Models::Stop> Catalog::MapBuilder::RemoveNeighbors(const Catalog::BusShedule& bus_schedule, std::vector<Models::Stop>& ordered) const
{
	if (ordered.size() > 1) {
		std::vector<Models::Stop> result;

		for (size_t current = 0; current < ordered.size();) {
			result.push_back(ordered[current]);
			std::vector<Models::Stop> current_group;
			current_group.push_back(ordered[current]);

			for (size_t next = current + 1; next < ordered.size(); ++next) {
				bool hasDirectRoute = false;

				for (const auto& stop : current_group) {
					hasDirectRoute = AreNeighborsOnSameRoute(bus_schedule, stop, ordered[next]);
					if (hasDirectRoute) {
						break;
					}
				}

				if (hasDirectRoute) {
					break;
				}
				else {
					current_group.push_back(ordered[next]);
				}
			}

			current = current + current_group.size();
		}
		return std::move(result);
	}
	else {
		return std::move(std::vector<Models::Stop>(ordered));
	}
}
