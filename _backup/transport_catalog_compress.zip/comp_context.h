#pragma once

#include "position.h"
#include "point.h"

#include <memory>
#include <vector>
#include <algorithm>

namespace Catalog {
	class ComputationContext
	{
	public:
		ComputationContext(double height, double padding, double x_step, double y_step, std::vector<double>&& ordered_lon, std::vector<double>&& ordered_lat);

		Svg::Point GetProjection(const Models::Position& position) const;
	private:
		double _height;
		double _padding;
		double _x_step;
		double _y_step;
		std::vector<double> _ordered_lon;
		std::vector<double> _ordered_lat;
	};
}

