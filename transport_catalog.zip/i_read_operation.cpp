#include "i_read_operation.h"

Operations::IReadOperation::~IReadOperation()
{
}
