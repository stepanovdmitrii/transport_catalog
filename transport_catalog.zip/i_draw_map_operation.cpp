#include "i_draw_map_operation.h"

Operations::IDrawMapOperation::~IDrawMapOperation()
{
}
