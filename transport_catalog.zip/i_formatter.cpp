#include "i_formatter.h"

IO::IFormatter::~IFormatter()
{
}
