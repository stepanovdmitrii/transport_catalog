#pragma once

namespace Svg {
	struct Point
	{
		Point();
		Point(double x_value, double y_value);

		double x;
		double y;
	};
}

