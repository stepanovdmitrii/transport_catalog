#include "i_map_builder_setup_operation.h"

Operations::IMapBuilderSetupOperation::~IMapBuilderSetupOperation()
{
}
