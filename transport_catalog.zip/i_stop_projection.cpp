#include "i_stop_projection.h"

Catalog::IStopProjection::~IStopProjection()
{
}
