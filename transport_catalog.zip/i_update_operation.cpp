#include "i_update_operation.h"

Operations::IUpdateOperation::~IUpdateOperation()
{
}
